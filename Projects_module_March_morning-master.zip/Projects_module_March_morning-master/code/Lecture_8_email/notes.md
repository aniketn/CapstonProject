**final forget and reset password is implemented on Ecommerce backend**
##  SASS service
Tracking and Auth 
* Users 
  * Email service : email and password
* Application : all these service will provide an `API key` to do auth , tracking of the app

## Emails
 * SMTP servers -> that are specifically designed to store and exchange Email (you will need a service)
 * template of emails are  follow quite older version of HTML and CSS

## Email Service Provider
* sendgrid
* mailgun
* mailchimp

## Setup Process for Sendgrid
* signup 
* 2 FA auth -> Enabling 
* Dashboard
* TO identify the email address of sender -> ask you identify that mail
* Email client 


## Email
* content and the context of the email
* also define -> the service
  * what SMTP server it provides
  * which port that SMTP server uses  




    







