## Homework 

## Problem Statement
* Implement update user in our API
* Add Product schema and CRUD methods for them as well