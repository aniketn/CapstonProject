## Foundational Facts
* Javascript engine-> it only give you logic
* Enviornment -> gives you the feature
    * Frontend : Browser-> (console, setTimout, Fetch , ajax)[web apis]
    * Backend : Nodejs (console,setTimout)
* Enviornment exposes all those features in the form of an `object`

## Installation
* Nodejs install lts  : https://nodejs.org/en
* Postman : is used to test your backend server


### Build server -> netflix
* work with  the files/directory -> fs 
* network calls -> http
* access to your os-> os
* work with path issues on cross platform-> path

<!-- UNIX-> os  
    LINUX -> os (open source)
        * mac os -> unix
        "/Users/apple/Documents/Projects_module_March_morning/notes"
    * dos based -> windows
         "\Users\apple\Documents\Projects_module_March_morning\notes" -->


### installing a node package
* npm init -y
* npm i nodemon --save-dev
