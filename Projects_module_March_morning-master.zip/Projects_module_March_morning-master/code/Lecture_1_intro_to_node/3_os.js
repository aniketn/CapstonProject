const os=require("os");
// console.log("arch", os.arch());
// console.log("cpus", os.cpus());
// console.log("platform", os.platform());
// console.log("os", os.freemem());
// console.log("ipconfig", os.networkInterfaces());