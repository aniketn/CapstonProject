// gives most of the info about current nodejs process
// console.log("process",process);
// console.log("global",global);

// fetch("http://localhost").the


