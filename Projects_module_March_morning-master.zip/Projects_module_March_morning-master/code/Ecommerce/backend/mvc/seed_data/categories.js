module.exports = [
    "electronics",
    "jewelery",
    "men's clothing",
    "women's clothing"
];